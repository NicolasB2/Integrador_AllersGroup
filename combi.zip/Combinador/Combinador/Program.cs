﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Combinador
{
    class Program
    {
        static void Main(string[] args)
        {
            //var n = new[] { "a", "b", "c", "d", "e"};
            //var n = generadorArreglos1();
            var n = generadorArreglos2();
            
            Console.Write("n: ");
            foreach (var item in n)
            {
                Console.Write("{0} ", item);
            }
            Console.WriteLine();
            Console.WriteLine();

            for(int r = 0; r<=n.Length; r++)
            {
            foreach (IEnumerable<string> i in Combinations(n, r))
                Console.WriteLine(string.Join(" ", i));

            }
            
            Console.ReadLine();
        }

        private static IEnumerable Combinations<T>(IEnumerable<T> elements, int k)
        {
            var elem = elements.ToArray();
            var size = elem.Length;

            if (k > size) yield break;

            var numbers = new int[k];

            for (var i = 0; i < k; i++)
                numbers[i] = i;

            do
            {
                yield return numbers.Select(n => elem[n]);
            } while (NextCombination(numbers, size, k));
        }

        private static bool NextCombination(IList<int> num, int n, int k)
        {
            bool finished;

            var changed = finished = false;

            if (k <= 0) return false;

            for (var i = k - 1; !finished && !changed; i--)
            {
                if (num[i] < n - 1 - (k - 1) + i)
                {
                    num[i]++;

                    if (i < k - 1)
                        for (var j = i + 1; j < k; j++)
                            num[j] = num[j - 1] + 1;
                    changed = true;
                }
                finished = i == 0;
            }

            return changed;
        }

        public static int[] generadorArreglos1()
        {
            int Min = 0;
            int Max = 20;


            int[] test2 = new int[10000];

            Random randNum = new Random();
            for (int i = 0; i < test2.Length; i++)
            {
                test2[i] = randNum.Next(Min, Max);
            }
            return test2;
        }

        public static char[] generadorArreglos2()
        {
            Random rnd = new Random();
            char[] letras = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

            int constante = 5;

            char[] aux = new char[constante];

            for (int i = 0; i < constante; i++)
            {
                aux[i] = letras[rnd.Next(0, 25)];
            }
            
            return aux;
        }
    }
}
